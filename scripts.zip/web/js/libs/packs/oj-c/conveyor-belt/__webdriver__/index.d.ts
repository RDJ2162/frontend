import { By } from 'selenium-webdriver';
import { DriverLike } from '@oracle/oraclejet-webdriver';
import { ConveyorBeltWebElement } from './ConveyorBeltWebElement';
export { ConveyorBeltWebElement };
/**
 * Retrieve an instance of [ConveyorBeltWebElement](../classes/ConveyorBeltWebElement.html).
 * @example
 * ```javascript
 * import { findConveyorBelt } from '@oracle/oraclejet-core-pack/webdriver';
 * const el = await findConveyorBelt(driver, By.id('my-oj-c-conveyor-belt'));
 * ```
 * @param driver A WebDriver/WebElement instance from where the element will be
 * searched. If WebDriver is passed, the element will be searched globally in the
 * document. If WebElement is passed, the search will be relative to this element.
 * @param by The locator with which to find the element
 */
export declare function findConveyorBelt(driver: DriverLike, by: By): Promise<ConveyorBeltWebElement>;
