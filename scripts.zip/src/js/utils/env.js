define([],
 function() {
    return{
        apiBaseUrl: 'http://localhost:8080'
    }
        
      

     }
    
  
);
